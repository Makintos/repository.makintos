# plugin.video.acestream.sports

Video plugin for [Kodi](http://kodi.tv) mediacenter.

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
